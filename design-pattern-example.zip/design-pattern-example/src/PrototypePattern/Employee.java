package PrototypePattern;

interface Employee {
	Employee employeeclone();
	void employeeDetails();
}
