package PrototypePattern;

public class Main {
	
	public static void main(String[] args){
		
		Employee employeePrototype = new EmployeeImpl("Pankaj", 100000);
		
		Employee employeeClone = employeePrototype.employeeclone();
		
		employeeClone.employeeDetails();
	}

}
