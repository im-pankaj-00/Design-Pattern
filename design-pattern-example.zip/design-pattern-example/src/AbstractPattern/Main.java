package AbstractPattern;

public class Main {

	public static void main(String[] args) {
		
        EmployeeFactory factory = new EmployeeAbstractFactory();
 
        // Using the factory to create an Employee object
        Employee employee = factory.createEmployee("Pankaj", 45000);
 
        // Printing details of the employee
        employee.employeeDetails();

	}
}
