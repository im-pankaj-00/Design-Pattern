package AbstractPattern;


public class EmployeeAbstractFactory implements EmployeeFactory {

	@Override
	public Employee createEmployee(String employeeName, int salary) {
		// TODO Auto-generated method stub
		return new Employee(employeeName, salary);
	}   
}