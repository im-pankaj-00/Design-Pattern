package FactoryPattern;

public class Employee {
	
	private String employeeName;
	private int salary;
	
	
	public Employee(String employeeName, int salary) {
		this.employeeName = employeeName;
		this.salary = salary;
	}
	
	public void employeeDetails(){
		System.out.println("Employee Details:");
		System.out.println("Employee Name: "+employeeName);
		System.out.println("Employee Salary: "+salary);
	}

}
