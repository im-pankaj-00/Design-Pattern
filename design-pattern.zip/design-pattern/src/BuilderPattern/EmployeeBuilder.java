package BuilderPattern;

public class EmployeeBuilder {
	
	private String employeeName;
	private int salary;
	
	public EmployeeBuilder(){
		
	}

	public EmployeeBuilder setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
		return this;
	}

	public EmployeeBuilder setSalary(int salary) {
		this.salary = salary;
		return this;
	}
	
	public Employee build(){
		return new Employee(employeeName, salary);
	}
}
