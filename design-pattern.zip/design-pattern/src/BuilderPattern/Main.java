package BuilderPattern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee employee = new EmployeeBuilder()
				.setEmployeeName("Pankaj")
				.setSalary(40000)
				.build();
		
		employee.employeeDetails();
	}

}
