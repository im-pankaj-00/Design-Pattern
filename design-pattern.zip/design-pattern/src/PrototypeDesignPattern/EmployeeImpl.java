package PrototypeDesignPattern;

public class EmployeeImpl implements Employee{
	
	private String employeeName;
	private int salary;
	
	public EmployeeImpl(String employeeName, int salary) {
		
		this.employeeName = employeeName;
		this.salary = salary;
	}
	
	@Override
	public Employee employeeclone(){
		return new EmployeeImpl(employeeName, salary);
	}
	
	@Override
	public void employeeDetails(){
		System.out.println("Employee Details: ");
		System.out.println("Employee Name: "+ employeeName);
		System.out.println("Employee Salary: "+ salary);
	}
	
	

}
