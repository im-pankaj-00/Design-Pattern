package PrototypeDesignPattern;

interface Employee {
	Employee employeeclone();
	void employeeDetails();
}
