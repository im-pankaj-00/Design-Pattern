package SingletonDesignPatthern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee employee = Employee.getEmployee();
		employee.EmployeeCreate();

	}

}
