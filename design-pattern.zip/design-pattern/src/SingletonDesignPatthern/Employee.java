package SingletonDesignPatthern;


public class Employee {
    
	private static Employee employee;
	
	//Constructor
	private Employee() {	
	}
	
	public static Employee getEmployee(){
		//object of this class
		if(employee == null){
			employee = new Employee();
		}
		return employee;
	}
	
	public void EmployeeCreate(){
		System.out.println("Employee Created...");
	}


}
