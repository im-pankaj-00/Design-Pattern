package FactoryPattern;


// Factory class for creating Employee objects
public class EmployeeFactory {
    public static Employee createEmployee(String employeeName, int salary) {
       
            return new Employee(employeeName, salary);
        
    }
}
