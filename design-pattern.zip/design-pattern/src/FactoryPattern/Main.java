package FactoryPattern;

public class Main {

	public static void main(String[] args) {
		
		// Using the factory to create an Employee object
        Employee employee = EmployeeFactory.createEmployee("Pankaj Sharma", 45000);
 
        // Printing details of the employee
        employee.employeeDetails();
	}

}
