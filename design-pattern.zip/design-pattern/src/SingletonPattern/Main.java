package SingletonPattern;

public class Main {
	public static void main(String[] args) {
		
		Employee employee = Employee.getInstance("Pankaj", 20000);
	    employee.printDetails();
	 }
}
