package SingletonPattern;


public class Employee {
	private static Employee instance;
	private String employeeName;
	private int salary;
	
	
	private Employee(String employeeName, int salary) {
		this.employeeName = employeeName;
		this.salary = salary;
	}

	public static Employee getInstance(String employeeName, int salary) {
		if (instance == null) {
			instance = new Employee(employeeName, salary);
		}
		return instance;
	}
	
	public void printDetails() {
		System.out.println("Employee Details:");
		System.out.println("Employee Name: " + employeeName);
		System.out.println("Employee Salary: " + salary);
	}
}