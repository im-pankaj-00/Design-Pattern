package FactoryDesignPattern;

interface Employee {

	int salary();
}
