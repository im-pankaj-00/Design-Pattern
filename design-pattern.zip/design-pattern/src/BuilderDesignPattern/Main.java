package BuilderDesignPattern;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee employee1 = new Employee.EmployeeBuilder()
				.setEmailId("pankaj123@gmail.com")
				.setEmployeeId("EMP01")
				.setEmployeeName("Pankaj")
				.build();
		
		System.out.println(employee1);
		
	    
	    Employee employee2 = new Employee.EmployeeBuilder()
	    		.setEmailId("Vikram@gmail.com")
			    .setEmployeeId("EMP02")
			    .setEmployeeName("Vikram")
			    .build();
	    System.out.println(employee2);
	    }
}