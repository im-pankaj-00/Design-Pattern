package BuilderDesignPattern;

public class Employee {
	
	private final String employeeId;
	private final String employeeName;
	private String emailId;
	
	private Employee(EmployeeBuilder builder) {
		//intialize
		this.employeeId = builder.employeeId;
		this.employeeName = builder.employeeName;
		this.emailId = builder.emailId;
	}
	
	
	public String getEmployeeId() {
		return employeeId;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}
	
	public String getEmailId() {
		return emailId;
	}
	
	
	@Override
	public String toString() {
		return this.employeeName + " : "+this.emailId+ " : "+this.employeeId;
	}

	
	// inner class to create object

	static class EmployeeBuilder {
		
		private String employeeId;
		private String employeeName;
		private String emailId;
		
		//Constructor
		public EmployeeBuilder(){
			
		}
		
		public EmployeeBuilder setEmployeeId(String employeeId) {
			this.employeeId = employeeId;
			return this;
		}

		public EmployeeBuilder setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
			return this;
		}

		public EmployeeBuilder setEmailId(String emailId) {
			this.emailId = emailId;
			return this;
		}
		
		public Employee build(){
			Employee employee = new Employee(this);
			return employee;
		}	
	}
}
