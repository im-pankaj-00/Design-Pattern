package Abstract;

public interface Employee {
	
	int salary();
	String name();

}
