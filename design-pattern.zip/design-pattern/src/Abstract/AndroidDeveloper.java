package Abstract;

public class AndroidDeveloper implements Employee{

	public int salary(){
		return 50000;
	}
	
	public String name(){
		System.out.println("I'm android developer");
		return "ANDROID DEVELOPER";
	}
}
