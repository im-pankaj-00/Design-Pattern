package Abstract;

public class WebDeveloper implements Employee{
	
	public int salary() {
		return 40000;
	}
	
	public String name() {
		System.out.println("I'm web developer");
		return "WEB DEVELOPER";
	}

}
