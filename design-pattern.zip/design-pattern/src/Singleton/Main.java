package Singleton;


public class Main {

	public static void main(String[] args) {
		
		// Using the singleton instance
		DatabaseConnection connection1 = DatabaseConnection.getInstance();
		connection1.connect();
		
		
        DatabaseConnection connection2 = DatabaseConnection.getInstance();
		connection2.connect();
		
		connection1.disconnect();
	}
}
