package AbstractPattern;


//Abstract factory interface
public interface EmployeeFactory {
 Employee createEmployee(String employeeName, int salary);
}